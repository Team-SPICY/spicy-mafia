$(dirname "$)")/scripts/gen_run_tests.py | bash
